def is_alive(health):
 if health < 0: return False
 else: return True
a=100
print(is_alive(a))
