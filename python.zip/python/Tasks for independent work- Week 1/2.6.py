# 1part
for i in range(101):
    if i < 50:
        print(i)
    elif i > 99:
        print(i)
x=0
while(x<=100):
    if x<50:
        print(x)
    elif x>99:
        print(x)
    x=x+1