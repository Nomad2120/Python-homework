i = 34
while i != 67:
    if i % 2 == 0:
        print(i)
    i = i + 1