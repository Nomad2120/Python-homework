a=float(input('Enter your result'))
b=(((a*5)+8)*2)
print(b)