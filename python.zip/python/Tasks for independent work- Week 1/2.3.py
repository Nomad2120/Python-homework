def triplecheck(x):
    if(x>10):
        while x!=12 and x<=15 or x==18:
            return True
        else:
            return False
n=14
print(triplecheck(n))