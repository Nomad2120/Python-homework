word=input('Enter your word:')
number=int(input('Enter your number'))
for x in word:
    for i in range(0, number):
        print(x);
