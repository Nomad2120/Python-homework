import math
x=4
print(((math.log1p(x-3)**4)+(2**x)*(math.sin(3*x)**2))/4*x-5.2)
