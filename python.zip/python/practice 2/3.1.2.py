import math
x=1
y=4
z=3
print((math.pow(math.fabs(math.cos(y))/(math.sin(y))+6,1/3))+((math.sqrt(x+1)**3)/(4*y-2*z)))
