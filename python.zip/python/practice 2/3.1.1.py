import math
x=2
y=1
print((x**y)**x+x**x**y-x**4)
