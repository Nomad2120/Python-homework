import math
x=0.5
y=2
print(((math.asin(x)**3)-6)/(8*(math.cos(4*y)-math.sin(4*x))))
