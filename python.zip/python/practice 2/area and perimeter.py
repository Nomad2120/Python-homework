import math
a = float(input("a: "))
b = float(input("b: "))
c=math.sqrt(a**2+b**2)
S=(a*b)/2
P=a+b+c
print ("Triangle area:% .2f"% S)
print ("Perimeter of triangle:% .2f"% P)

