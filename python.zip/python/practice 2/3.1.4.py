import math
x=3
y=5
print((math.sqrt(math.fabs(y)))+(math.atan(math.log1p(x))**3)/((x**y)-y+1))
