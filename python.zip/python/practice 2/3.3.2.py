import math
x=2
y=2
z=1
print((math.sqrt(0.6*x*y*z))+((y**x)**2)-math.exp(math.sin(2*x)**2))
