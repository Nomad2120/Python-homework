import math
x=3
y=1
z=2
print((4**(x*y))-(x**(y*z))+((x*y)**z))
