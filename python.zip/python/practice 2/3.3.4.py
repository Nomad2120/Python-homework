import math
x=2
y=1
z=3
print((((math.log1p(x)**3)+math.exp(2*x))/(x+3.4))-(math.tan(1/(3/x*y*z))**3))
