import math
a=int(input('enter the var a:'))
b=int(input('enter the var b:'))
h=int(input('enter the var h:'))
s=((a*a+b)*h)/(2*(a-b)+4)
print('your solution %.2f'%s)
