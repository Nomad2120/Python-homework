import math
x=2
y=2
z=1
print((4*(math.fabs(x))-(x*y*(z**2)))/(x+(math.exp(y*x))-2*y*z))
