import math
x=0.8
y=0.1
z=4
print(math.pow((1-x+(math.atan(1/(x-7*y))))/(4*x*z-((math.log1p(x))**2),1/5)))
