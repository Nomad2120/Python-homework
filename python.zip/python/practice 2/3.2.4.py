import math
x=3
y=1
z=3
print((2*3*4)/((math.sin(x)**3)+(math.tan(y)**3))-(math.sqrt(z**(x-y))))
