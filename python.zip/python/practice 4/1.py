n=int(input('Enter cost: \n'))
for i in range(1,10):
    print('the cost of',i,'sweets is',n*i)
